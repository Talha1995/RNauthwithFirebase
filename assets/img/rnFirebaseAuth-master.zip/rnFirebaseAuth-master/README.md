# rnFirebaseAuth
In this React Native tutorial, we are going to learn how to create Login and User Registration functionalities using Firebase Authentication services.

[React Native Firebase – Login and User Registration Tutorial](https://www.positronx.io/react-native-firebase-login-and-user-registration-tutorial/)


## Start the React Native Firebase Authentication App
* `git clone https://github.com/SinghDigamber/rnFirebaseAuth.git`
* `cd rnFirebaseAuth`
* `npm install`
* Enter your Firebase credentials in database > firebase.js
